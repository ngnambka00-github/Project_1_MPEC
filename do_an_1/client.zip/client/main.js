
$(document).ready(function(){
    // thực hiện code jquery
    $(".header .header-menu .menu-header-icon a").click(function() {
        $(".show-menu").removeClass("display-none");
        // $(".show-menu").find('.box-menu').css('background', 'linear-gradient(to right, white 50%, white 50%)');
        $(".show-menu").find('.box-menu').addClass('change-background-color');
    });

    $('body').on('click', '.show-menu', function(event) {
        if ($(event.target).hasClass('show-menu')) {
            $(".show-menu").addClass("display-none");     
            $(".show-menu").find('.box-menu').removeClass('change-background-color');
        }
    });

    // Tạo sự kiện click cho button giỏ hàng
    $('.header .header_search .box-shopping .fa-shopping-cart').click(function() {
        $('.show-gio-hang').removeClass('display-none');
    });
    // Tạo sự kiện đóng tab giỏ hàng
    $('.close-gio-hang').click(function() {
        $('.show-gio-hang').addClass('display-none');
    });
    $('body').on('click', '.show-gio-hang', function(event) {
        if ($(event.target).hasClass('show-gio-hang')) {
            $(".show-gio-hang").addClass("display-none");     
        }
    });


    // Tạo sự kiện cho button User
    $('.header .header_search .box-user .fa-user').click(function() {
        $('.show-dang-nhap').removeClass('display-none');
        console.log("fdsaf");
    });
    // Tạo sự kiện đóng tab đăng nhập / đăng ký
    $('.close-dang-nhap').click(function() {
        $('.show-dang-nhap').addClass('display-none');
    });
    $('body').on('click', '.show-dang-nhap', function(event) {
        if ($(event.target).hasClass('show-dang-nhap')) {
            $(".show-dang-nhap").addClass("display-none");     
        }
    });


    /*=====================================================================*/ 
    // Hiệu ứng slide cho phần quảng cáo giảm giá 

    var timeNextSlide = 5000;
    // Thực hiện cho slide quảng cáo các chương trình khuyến mãi chạy tự động nếu không thao tác gì
    function nextSlideAuto() {
        let buttonNext = $('.slide-giam-gia .button-dieu-huong > .next');
        // Ngăn vừa việc click quá nhiều cùng 1 lúc
        buttonNext.addClass('no-click');

        // Lấy vị trí của slide hiện tại 
        let indexSlideCurrent = $('.slide-giam-gia .danh-sach-slide .slide.active').index() + 1; 

        // Tìm slide đang có active 
        // -> biến mất thẻ hiện tại sang trái 
        // -> xuất hiện thẻ kế tiếp sang trái
        let slideTiepTheo = $('.slide-giam-gia .danh-sach-slide .slide.active').next();

        // Nễu có slide tiếp theo thì next
        // Không có thì trả về cái đầu tiên
        if (slideTiepTheo.length) {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:nth-child(${indexSlideCurrent + 1})`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-trai');
                })

            slideTiepTheo
                .addClass('active')
                .addClass('xuat-hien-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-trai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonNext.removeClass('no-click');
                });
                
            
        } else {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:first-child`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-trai');
                });

            $('.slide-giam-gia .danh-sach-slide .slide:first-child')
                .addClass('active')
                .addClass('xuat-hien-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-trai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonNext.removeClass('no-click');
                });
        }
    }

    var handelInterval = setInterval(nextSlideAuto, timeNextSlide);

    // Hiệu ứng next
    $('.slide-giam-gia .button-dieu-huong > .next').click(function() {
        clearInterval(handelInterval);

        let buttonNext = $(this);
        // Ngăn vừa việc click quá nhiều cùng 1 lúc
        buttonNext.addClass('no-click');

        // Lấy vị trí của slide hiện tại 
        let indexSlideCurrent = $('.slide-giam-gia .danh-sach-slide .slide.active').index() + 1; 

        // Tìm slide đang có active 
        // -> biến mất thẻ hiện tại sang trái 
        // -> xuất hiện thẻ kế tiếp sang trái
        let slideTiepTheo = $('.slide-giam-gia .danh-sach-slide .slide.active').next();

        // Nễu có slide tiếp theo thì next
        // Không có thì trả về cái đầu tiên
        if (slideTiepTheo.length) {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:nth-child(${indexSlideCurrent + 1})`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-trai');
                })

            slideTiepTheo
                .addClass('active')
                .addClass('xuat-hien-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-trai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonNext.removeClass('no-click');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });
                
            
        } else {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:first-child`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-trai');
                });

            $('.slide-giam-gia .danh-sach-slide .slide:first-child')
                .addClass('active')
                .addClass('xuat-hien-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-trai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonNext.removeClass('no-click');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });
        }
    });


    // Hiệu ứng previous
    $('.slide-giam-gia .button-dieu-huong > .previous').on('click', function() {
        clearInterval(handelInterval);

        let buttonPrevious = $(this);
        // Ngăn vừa việc click quá nhiều cùng 1 lúc
        buttonPrevious.addClass('no-click');

        // Lấy vị trí của slide hiện tại 
        let indexSlideCurrent = $('.slide-giam-gia .danh-sach-slide .slide.active').index() + 1; 

        // Tìm slide đang có active 
        // -> biến mất thẻ hiện tại sang trái 
        // -> xuất hiện thẻ kế tiếp sang trái
        let slideTiepTheo = $('.slide-giam-gia .danh-sach-slide .slide.active').prev();

        // Nễu có slide tiếp theo thì next
        // Không có thì trả về cái đầu tiên
        if (slideTiepTheo.length) {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:nth-child(${indexSlideCurrent - 1})`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-phai');
                });

            slideTiepTheo
                .addClass('active')
                .addClass('xuat-hien-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-phai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonPrevious.removeClass('no-click');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });
                
            
        } else {
            // Active cho phím chuyển slide ở dưới bottom 
            $('.slide-giam-gia .button-dieu-huong > .bottom > li')
                .removeClass('active-button-slide');
            $(`.slide-giam-gia .button-dieu-huong > .bottom > li:last-child`)
                .addClass('active-button-slide');

            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-phai');
                });

            $('.slide-giam-gia .danh-sach-slide .slide:last-child')
                .addClass('active')
                .addClass('xuat-hien-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-phai');

                    // Khi kết thúc animation thì mới cho click tiếp 
                    buttonPrevious.removeClass('no-click');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });
        }
    });


    // sự kiện click vào các button chấm tròn ở dưới slide quảng cáo 
    $('.slide-giam-gia .button-dieu-huong > .bottom > li').click(function() {
        clearInterval(handelInterval); 

        let indexButtonClick = $(this).index();
        let currentSlide = $('.slide-giam-gia .danh-sach-slide .slide.active').index();
        
        // Active cho button ở bottom chả slide
        $('.slide-giam-gia .button-dieu-huong > .bottom > li')
            .removeClass('active-button-slide');
        $(`.slide-giam-gia .button-dieu-huong > .bottom > li:nth-child(${indexButtonClick + 1})`)
            .addClass('active-button-slide');    

        // chạy slide theo hướng của button next
        if (indexButtonClick > currentSlide) {
            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-trai');
                });

            $(`.slide-giam-gia .danh-sach-slide .slide:nth-child(${indexButtonClick + 1})`)
                .addClass('active')
                .addClass('xuat-hien-sang-trai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-trai');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });;

        } 
        // Chạy slide theo hướng của buton previous
        else if (indexButtonClick < currentSlide) {
            $('.slide-giam-gia .danh-sach-slide .slide.active')
                .addClass('bien-mat-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('active')
                        .removeClass('bien-mat-sang-phai');
                });

            $(`.slide-giam-gia .danh-sach-slide .slide:nth-child(${indexButtonClick + 1})`)
                .addClass('active')
                .addClass('xuat-hien-sang-phai')
                .one('webkitAnimationEnd', function() {
                    $(this).removeClass('xuat-hien-sang-phai');
                    handelInterval = setInterval(nextSlideAuto, timeNextSlide);
                });;
        }
    });

    // Kết thúc phần tạo hiệu ứng slide cho quảng cáo giảm giá 
    /*=====================================================*/ 


    $('.header .header-menu .menu-header-icon a').click(function(event){
        event.preventDefault();
    });
});